import java.util.Arrays;



public class App {

    static int retorno;
    public static int metodo(int x) {

        int y = 2 * x;
        int indicador = 0;
        if (x % 2 == 0) {
            System.out.println("É isso");
            retorno = 3 * x;
        } else {
            System.out.println("É aquilo");
            for (int i = 0; i < y; i++) {
                retorno += y - i;
            }
        }
        return retorno;
    }
    public static void main(String[] args) throws Exception {
        metodo(5);
    }
}
