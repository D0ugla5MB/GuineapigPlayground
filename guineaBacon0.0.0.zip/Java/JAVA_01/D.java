<<<<<<< HEAD
public class D {
    private String SHADOW = "i am the original var";

    public String SHADOW(){
        String SHADOW = "";
        return "No,\s"+SHADOW+"\sI am the original one";
    }
    
=======
public class D {
    private String SHADOW = "i am the original var";

    public String SHADOW(){
        String SHADOW = "";
        return "No,\s"+SHADOW+"\sI am the original one";
    }
    
>>>>>>> parent of dc1dbf4 (fix class issue)
}