$params = Get-Date -UFormat "%H:%M:%S";

Invoke-Command {.\Main.exe $params};