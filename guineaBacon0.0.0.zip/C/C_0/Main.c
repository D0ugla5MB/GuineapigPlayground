#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int main(int argc, char *argv[])
{
    int arr[5] = {0, 0, 0, 0, 0};
    size_t size = sizeof(arr) / sizeof(int);
    int *arrAux = malloc(size * sizeof(int));
    arrAux = &arr;

    for (size_t i = 0; i < size; i++)
    {
        arr[i] = i;
    }

    for (size_t i = 0; i < size; i++)
    {
        printf("%d ", *(arrAux + i));
    }
    printf("\n%d", sizeof(arrAux) / sizeof(int));

        free(arrAux);

    return 0;
}