import * as search from "./search.js";
import * as tags from "./tags.js";

setTimeout(search.getSearchData, 2000);
