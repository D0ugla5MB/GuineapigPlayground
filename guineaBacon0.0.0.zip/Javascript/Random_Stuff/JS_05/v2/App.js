import * as cont from "./PrepareContent.js";

const a = new cont.Owner();
console.log(a.name);
console.log(a.cats);
