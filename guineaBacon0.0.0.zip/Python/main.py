
from typing import Final
from letters import *

def test(func):
    print(func)

def getFuncRes(func):
    return func

print(PIECES[0])